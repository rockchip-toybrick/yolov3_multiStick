#!/bin/bash

python3 yolov3_server.py > /home/toybrick/yolov3.log 2>&1 &
