import cv2
import time
import numpy as np
import sys
from multiprocessing import Process, Queue, Lock
import multiprocessing
from rknn_client_class import rknn_client

CLASSES = ("person", "bicycle", "car","motorbike ","aeroplane ","bus ","train","truck ","boat","traffic light",
           "fire hydrant","stop sign ","parking meter","bench","bird","cat","dog ","horse ","sheep","cow","elephant",
           "bear","zebra ","giraffe","backpack","umbrella","handbag","tie","suitcase","frisbee","skis","snowboard","sports ball","kite",
           "baseball bat","baseball glove","skateboard","surfboard","tennis racket","bottle","wine glass","cup","fork","knife ",
           "spoon","bowl","banana","apple","sandwich","orange","broccoli","carrot","hot dog","pizza ","donut","cake","chair","sofa",
           "pottedplant","bed","diningtable","toilet ","tvmonitor","laptop  ","mouse    ","remote ","keyboard ","cell phone","microwave ",
           "oven ","toaster","sink","refrigerator ","book","clock","vase","scissors ","teddy bear ","hair drier", "toothbrush ")

def draw(image, boxes, scores, classes):
    """Draw the boxes on the image.

    # Argument:
        image: original image.
        boxes: ndarray, boxes of objects.
        classes: ndarray, classes of objects.
        scores: ndarray, scores of objects.
        all_classes: all classes name.
    """
    for box, score, cl in zip(boxes, scores, classes):
        x, y, w, h = box
        #print('class: {}, score: {}'.format(CLASSES[cl], score))
        #print('box coordinate left,top,right,down: [{}, {}, {}, {}]'.format(x, y, x+w, y+h))
        x *= image.shape[1]
        y *= image.shape[0]
        w *= image.shape[1]
        h *= image.shape[0]
        top = max(0, np.floor(x + 0.5).astype(int))
        left = max(0, np.floor(y + 0.5).astype(int))
        right = min(image.shape[1], np.floor(x + w + 0.5).astype(int))
        bottom = min(image.shape[0], np.floor(y + h + 0.5).astype(int))

        # print('class: {}, score: {}'.format(CLASSES[cl], score))
        # print('box coordinate left,top,right,down: [{}, {}, {}, {}]'.format(top, left, right, bottom))

        cv2.rectangle(image, (top, left), (right, bottom), (255, 0, 0), 2)
        cv2.putText(image, '{0} {1:.2f}'.format(CLASSES[cl], score),
                    (top, left - 6),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (0, 0, 255), 2)

        # print('class: {0}, score: {1:.2f}'.format(CLASSES[cl], score))
        # print('box coordinate x,y,w,h: {0}'.format(box))


def video_capture(q_frame:Queue, q_image:Queue, flag):
    video = cv2.VideoCapture(0)
    print("video.isOpened()={}", video.isOpened())
    try:
        while True:
            if flag.value == 10:
                if video.isOpened():
                    video.release()
                    print("video release!")
                print("exit video_capture!")
                break
            s = time.time()
            #print('capture q_image.qsize() = {}. '.format(q_image.qsize()))
            ret, frame = video.read()
            assert ret, 'read video frame failed.'
            #print('capture read used {} ms.'.format((time.time() - s) * 1000))

            s = time.time()
            image = cv2.resize(frame, (416, 416))
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            #print('capture resize used {} ms.'.format((time.time() - s) * 1000))

            s = time.time()
            if q_frame.empty():
                q_frame.put(frame)
            if q_image.full():
                continue
            else:
                q_image.put(image)
            #print("capture put to queue used {} ms".format((time.time()-s)*1000))
    except KeyboardInterrupt:
        video.release()
        print("exit video_capture!")

def infer_rknn(ip, q_image:Queue, q_objs:Queue, flag):
    rknn = rknn_client(ip, 8002)
    try:
        while True:
            s = time.time()
            if q_image.empty():
                continue
            else:
                image = q_image.get()
            #print('Infer{} q_image.qsize() = {}. '.format(dev_idx, q_image.qsize()))
            #print('Infer get, used time {} ms. '.format((time.time() - s) * 1000))

            s = time.time()
            boxes, classes, scores = rknn.inference(inputs=[image])

            if q_objs.full():
                continue
            else:
                q_objs.put((boxes, classes, scores))
    except KeyboardInterrupt:
        print("exit infer_rknn!")

if __name__ == '__main__':
    q_frame = Queue(maxsize=1)
    q_image = Queue(maxsize=12)
    q_objs = Queue(maxsize=6)
    flag = multiprocessing.Value("d", 0)

    p_cap1 = Process(target=video_capture, args=(q_frame, q_image, flag))
    #p_cap2 = Process(target=video_capture, args=(q_frame, q_image, flag))
    p_infer1 = Process(target=infer_rknn, args=("192.168.180.8", q_image, q_objs, flag))
    p_infer2 = Process(target=infer_rknn, args=("192.168.180.9", q_image, q_objs, flag))

    p_cap1.start()
    #p_cap2.start()
    p_infer1.start()
    p_infer2.start()

    fps = 0
    l_used_time = []

    try:
        while True:
            s = time.time()
            #print('main func, q_frame.qsize() = {}. '.format(q_frame.qsize()))
            frame = q_frame.get()
            boxes, classes, scores = q_objs.get()
            #print('main func, get objs use {} ms. '.format((time.time() - s) * 1000))

            if boxes is not None:
                draw(frame, boxes, scores, classes)
            cv2.putText(frame, text='FPS: {}'.format(fps), org=(3, 15), fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                                 fontScale=0.50, color=(255, 0, 0), thickness=2)
            cv2.imshow("results", frame)

            c = cv2.waitKey(5) & 0xff
            if c == 27:
                flag.value = 10
                time.sleep(5)
                cv2.destroyAllWindows()
                print("ESC, exit main!")
                break

            used_time = time.time() - s
            l_used_time.append(used_time)
            if len(l_used_time) > 20:
                l_used_time.pop(0)
            fps = int(1/np.mean(l_used_time))
            #print('main func, used time {} ms. '.format(used_time*1000))
    except KeyboardInterrupt:
        time.sleep(5)
        cv2.destroyAllWindows()
        print("ctrl + c, exit main!")

    p_cap1.terminate()
    #p_cap2.terminate()
    p_infer1.terminate()
    p_infer2.terminate()
    sys.exit()
