Chinese Guide: http://t.rock-chips.com/wiki.php?mod=view&id=74
English Guide: http://t.rock-chips.com/en/wiki.php?mod=view&id=59